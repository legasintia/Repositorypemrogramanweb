<?php
// Membuat Koneksi Ke database My SQL
	$host	='localhost';//Nama Server
	$user	='root'; //Username
	$pass	='';//----Pasword root----
	$db 	='db_ci_lega'; //------Nama Databases--
	
	$ok 	= mysql_connect($host,$user,$pass) or die ('Semangat'.mysql_error()); // Perintah menghubngkan Ke server
		mysql_select_db($db,$ok); // Perintah Menyeleksi Database
?>