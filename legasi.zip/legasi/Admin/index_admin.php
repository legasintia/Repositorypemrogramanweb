<!DOCTYPE html> 
<html lang="en"> 
<head> 
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<title>Halaman Biodata Lega Sintia</title> 
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<script src="js/jquery-1.11.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.style1 {font-size: large}
-->
</style></head>

<body>
<div class="container"> 
<div class="row">
<div class="col-md-12 btn-default">
  <div align="center" class="bg-primary style1"><strong>"TUGAS UTS LEGA SINTIA"</strong></div>
</div>
</div>

<div class="col-md-12">
  <h5 class="text-active"><span class="style6 style1"> <strong>
    <marquee scrollamount="3" class="alert-danger">
    <i>~~~" SELAMAT DATANG DI FORUM BIODATA LEGA SINTIA&quot;~~~</i>
    </marquee>
  </strong> </span></h5>
</div>

<div class="col-md-3"><br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<a href="?page=tampil_user"><button class="btn btn-block bg-primary">BIODATA</button></a><br>
</div>
    <div class="col-md-9">
    <div class="col-md-12"><?php include "content.php"; ?> </div>
</div>
</body>
</html>
