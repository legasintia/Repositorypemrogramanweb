<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php
include "../inc/koneksi.php";
	$Npm_user = $_GET['Npm'];
	$query = mysql_query("select * from tb_biodata_sintia where npm='$Npm_user'");
	$data = mysql_fetch_array($query);
	echo $Npm_user;
	?>

<body>
<p>Tambah data user</p>
<form id="form1" name="form1" method="post" action="">
  <table width="200" border="1">
    <tr>
      <td>Npm</td>
      <td>&nbsp;</td>
      <td><label>
        <input type="text" name="npm" id="npm" value="<?php echo $data['npm']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Nama</td>
      <td>&nbsp;</td>
      <td><label>
        <input type="text" name="nama" id="nama" value="<?php echo $data ['nama']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Kelas</td>
      <td>&nbsp;</td>
      <td><label>
        <input type="text" name="kelas" id="kelas" value="<?php echo $data ['kelas']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Jurusan</td>
      <td>&nbsp;</td>
      <td><label>
      <input type="text" name="jurusan" id="jurusan" value="<?php echo $data ['jurusan']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><label>
        <input type="submit" name="button" id="button"/>
      </label></td>
    </tr>
  </table>
</form>
<?php

if(isset($_POST['button'])){
$Npm=$_POST['npm'];
$Nama=$_POST['nama'];
$Kelas=$_POST['kelas'];
$Jurusan=$_POST['jurusan'];
$edit = mysql_query("UPDATE tb_biodata_sintia SET Npm='$Npm',Nama='$Nama',Kelas='$Kelas',Jurusan='$Jurusan' WHERE Npm ='$Npm_user' ");
if( $edit){
echo "Berhasil";}else
{ echo "gagal";
}
}
?>
</body>
</html>