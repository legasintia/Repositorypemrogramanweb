<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style3 {
	font-size: x-large
}
-->
</style>
</head>
<?php
include "../inc/koneksi.php";
$query=mysql_query("select * from tb_biodata_sintia");

?>
<body>
<p align="center" class="style3 style3"><strong>DATA BIODATA LEGA SINTIA</strong></p>
<div class="col-md-4">
<p><a href="?page=input_user">
<button class="btn btn-succes bg-primary">Tambah Data</button>
</a></p>
<table width="713" border="1">
  <tr>
    <td width="120"><div align="center"><strong>Npm</strong></div></td>
    <td width="140"><div align="center"><strong>Nama</div></td>
    <td width="132"><div align="center"><strong>Kelas</strong></div></td>
    <td width="138"><div align="center"><strong>Jurusan</strong></div></td>
    <td colspan="2"><div align="center"><strong>Aksi</strong></div></td>
  </tr>
  <?php while ($data=mysql_fetch_array($query)) { ?>
  <tr>
    <td><div align="justify"><?php echo $data['npm']; ?></div></td>
    <td><div align="justify"><?php echo $data['nama']; ?></div></td>
    <td><div align="justify"><?php echo $data['kelas']; ?></div></td>
    <td><div align="justify"><?php echo $data['jurusan']; ?></div></td>
   <td width="71"><div align="center"><a href="?page=edit_user&Npm=<?php echo $data['npm']; ?>">Edit</a></div></td>
	<td width="72"><div align="center"><a href="?page=hapus_user&Npm=<?php echo $data['npm']; ?>">Hapus</a></div></td>
  </tr><?php } ?>
</table>
<p>&nbsp; </p>
</body>
</html>
