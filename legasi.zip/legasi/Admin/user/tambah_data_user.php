<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title></head>

<body>
<p><strong>Tambahkan Data Biodata</strong></p>
<form id="form1" name="form1" method="post" action="">
  <table width="273" border="1">
    <tr>
      <td width="61"><strong>Npm</strong></td>
      <td width="44">&nbsp;</td>
      <td width="146"><label>
        <input type="text" name="npm" id="npm" />
      </label></td>
    </tr>
    <tr>
      <td><strong>Nama</strong></td>
      <td>&nbsp;</td>
      <td><label>
        <input type="text" name="nama" id="nama" />
      </label></td>
    </tr>
    <tr>
      <td><strong>Kelas</strong></td>
      <td>&nbsp;</td>
      <td><label>
        <input type="text" name="kelas" id="kelas" />
      </label></td>
    </tr>
    <tr>
      <td><strong>Jurusan</strong></td>
      <td>&nbsp;</td>
      <td><label>
      <input type="text" name="jurusan" id="jurusan" />
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><label>
        <input type="submit" name="button" id="button" value="Simpan" />
      </label></td>
    </tr>
  </table>
</form>
<?php
include "../inc/koneksi.php";
if(isset($_POST['button'])){
$Npm=$_POST['npm'];
$Nama=$_POST['nama'];
$Kelas=$_POST['kelas'];
$Jurusan=$_POST['jurusan'];
$simpan=mysql_query("insert into tb_biodata_sintia values ('$Npm','$Nama','$Kelas','$Jurusan')");
if($simpan){
echo "Berhasil";}else
{ echo "gagal";
}
}

?>
</body>
</html>