<?php
@session_start();
include "../inc/koneksi.php";
?>
<?php 
	$Npm_user = $_GET['Npm'];
	$query = mysql_query("delete from tb_biodata_sintia where Npm = '$Npm_user'");
	if($query){
	echo "<script>alert('Data berhasil dihapus')</script>";
	echo"<meta http-equiv='refresh' content='0;url=?page=profil'>";
	} else {
		echo "Data anda gagal didihapus. Ulangi sekali lagi";
	}
	
	?> 