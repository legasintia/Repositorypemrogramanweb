<style type="text/css">
<!--
.style3 {font-size: 36px}
-->
</style>
  <div class="row">
    <div class="col-md-12">
      <header>
        PEMERINTAHAN KOTA PAGARALAM KECAMATAN PAGARALAM SELATAN KELURAHAN BESEMAH SERASAN
                JL.Serma semat padang karet Rt.22 Rw.06 Kode pos 31525          
</nav>
                </header>
      <img src="<?php echo base_url(); ?>/assets/logo.jpeg" width="104" height="126" /><img src="<?php echo base_url(); ?>/assets/lur.jpg" width="869" height="123" />
            <img src="<?php echo base_url(); ?>/assets/logo.jpeg" width="95" height="126" />
<div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
<button class="btn btn-style btn-pale">Home</button>
<button class="btn btn-style btn-pale">Profil</button>
<button class="btn btn-style btn-pale">Visi&Misi</button>
<button class="btn btn-style btn-pale">Kegiatan</button>
<button class="btn btn-style btn-pale">Galeri</button>
<button class="btn btn-style btn-pale">Informasi</button>
<button class="btn btn-style btn-pale ">Data Pegawai</button>




      </div>

            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="?page=home"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href=""><i class="glyphicon glyphicon-th"></i> Profil <span class='caret'></span></a>
                  <ul class="dropdown-menu">
                                    <li><a href="?page=sejarah">Sejarah</a></li>
                    <li><a href="?page=visimisi">Visi & Misi</a></li>
                    <li><a href="?page=struktur">Kegiatan</a></li>
                                     
                  </ul>
                </li>
                                
<li><a href="?page=Galeri"><i class="glyphicon glyphicon-picture"></i>Galeri</a></li>
<li><a href="?page=Informasi"><i class="glyphicon glyphicon-book"></i>Informasi</a></li>
<li><a href="?page=Data Pegawai"><i class="glyphicon glyphicon-book"></i>Data Pegawai</a></li>

                                
                <li class="dropdown"></li>
 

                
              </ul>
      </div>
                        <span style="color:#000000"><em><span class="style3"></span>
                        <marquee bgcolor="#00FF66">
                        <strong>PEMERINTAHAN KOTA PAGARALAM KECAMATAN PAGARALAM SELATAN KELURAHAN BESEMAH SERASAN
                JL.Serma semat padang karet Rt.22 Rw.06 Kode pos 31525 </strong>
                        </marquee>
                        </em><span style="color:#000000">
          </nav>
          </header>


  </div>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/booststrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/booststrap.min.js"></script>
   
   </body>
   </html>
