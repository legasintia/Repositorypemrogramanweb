    <div class="col-md-6">
			<article>
			
<div class="active list-group-item">
<p><em><strong>KELURAHAN BESEMAH SERASAN</strong></em></div>
<form id="form1" name="form1" method="post" action="">
  <label>SELAMAT DATANG DI WEBSITE KANTOR LURAH BESEMAH SERASAN</label>
</form>
<p><img src="lur.jpg" width="264" height="140" /><img src="<?php echo base_url(); ?>assest/images (8).jpeg" width="250" height="139" /></p>
				</article>
		</div>
        
<div class="col-md-3">
<div class="list-group">
<a href="#" class="list-group-item active"><em class="glyphicon glyphicon-file"></em>Berita Kelurahan Besemah Serasan</a>
<div class="alert alert-success"></div>
</div>
<div class="alert alert-success"></div>
</div>
</div>	<!--baris tutup-->


	<div class="row">
		<div class="col-md-12">
			<footer class="well">
			  <p>Copyright &copy; 2019</p>
			</footer>
		</div>
	</div>
</div>
<script type="text/javascript">
							$(function() {
									//bootstrap WYSIHTML5 - text editor
									$(".textarea").wysihtml5();
  								$('[data-toggle="tooltip"]').tooltip();
							});
							
	</script>

</body>
</html>