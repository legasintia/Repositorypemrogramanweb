
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-=1>
	initial-scale=1, sharink-to-fit=no">
	<!-- coding css boostrap -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url (); ?>assets/css/Bootstrap.min.css">
	<title>Blogku</title>
</head>  
