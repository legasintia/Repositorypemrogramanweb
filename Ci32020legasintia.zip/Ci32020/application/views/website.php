<!DOCTYPE html>
<html>
<head>
	<title>website</title>
   </head>
   </body>
   <h3> Nama website</h3>
   <p> Isi Tentang website</p>
   
   </body>
   </html>