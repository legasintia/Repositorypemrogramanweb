<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-=1>
	initial-scale=1, sharink-to-fit=no">
	<!-- coding css boostrap -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url (); ?>assets/css/Bootstrap.min.css">
	<title>Belanjar Bootsrrap</title>
</head>
</body>
	<div class="container">
   <div  class="alert-warning"><h3 class="text text*primary">Nama website</h3>
   <div class="alert alert-info"><p> Isi Tentang website</p></div>
</div>
   
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/booststrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/booststrap.min.js"></script>
   
   </body>
   </html>