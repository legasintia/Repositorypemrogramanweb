<form method="post" action="<?php echo base_url().'pegawai/add'; ?>"
>
<!-- Modal -->
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pegawai</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div class="form-group">
       <label class="col-md-2">NIP</label>
       <div class="col-md-10">
       <input type="text" name="nip" class="form-control"
       placeholder="NIP">
         </div>
  	   </div>
      <div class="modal-body">
       <div class="form-group">
       <label class="col-md-2">Nama</label>
       <div class="col-md-10">
       <input type="text" name="nama" class="form-control"
       placeholder="Nama Lengkap">
       </div> 
       </div>
      <div class="modal-body">
       <div class="form-group">
       <label class="col-md-2">Jenis Kelamin</label>
       <div class="col-md-10">
       <div class="form-check">
  <input class="form-check-input" type="radio" name="jk" id="exampleRadios2" value="Laki-Laki">
  <label class="form-check-label" for="exampleRadios2">
   Laki-Laki
  </label>
</div>
 <div class="form-check">
  <input class="form-check-input" type="radio" name="jk" id="exampleRadios2" value="Perempuan">
  <label class="form-check-label" for="exampleRadios2">
   Perempuan 
  </label>
</div>
<div class="form-group row">
	<label class ="col-md-2">Jabatan</label>
	<div class="col-md-10">
		<select multiple class="form-control" id="exampleFormControlSelect1"name="jabatan">
      <option>Skretaris Kpegawaian</option>
      <option>Bendahara Kpegawaian</option>
      <option>Staf Kepegawaian</option>
    </select>
       
       </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
