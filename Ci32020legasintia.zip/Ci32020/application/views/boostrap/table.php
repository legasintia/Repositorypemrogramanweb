<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-=1>
	initial-scale=1, sharink-to-fit=no">
	<!-- coding css boostrap -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url (); ?>assets/css/Bootstrap.min.css">
	<title>Belanjar Bootsrrap</title>
</head>
<div class="container">
		<div class="alert alert-primary"><h3>Tabel Bootstrap</h3></div>
		<table class="table">
			<tr>
				<th>Nomor</th>
				<th>Nama</th>
				<th>NPM</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>Program Studi</th>
			</tr>
			<tr>
			<td>1</td>
			<td>Lega Sintia</td>
			<td>17420013</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		
		</tr>
		<tr>
			<td>2</td>
			<td>Ella Sari Gustini</td>
			<td>17420014</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>3</td>
			<td>Meiliza Putri</td>
			<td>17420021</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>

		</table>
<div class="alert alert-primary"><h3>Tabel Bootstrap</h3></div>
		<table class="table table-bordered">
			<tr>
				<th>Nomor</th>
				<th>Nama</th>
				<th>NPM</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>Program Studi</th>
			</tr>
			<tr>
			<td>1</td>
			<td>Lega</td>
			<td>17420013</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>2</td>
			<td>Ella Sari Gustini</td>
			<td>17420014</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>3</td>
			<td>Meiliza Putri</td>
			<td>17420021</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		</tr>

		</table>
<div class="alert alert-primary"><h3>Tabel Bootstrap Striped</h3></div>
		<table class="table table-Striped">
			<tr>
				<th>Nomor</th>
				<th>Nama</th>
				<th>NPM</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>Program Studi</th>
			</tr>
			<tr>
			<td>1</td>
			<td>Lega</td>
			<td>17420013</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>2</td>
			<td>Ella Sari Gustini</td>
			<td>17420014</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>3</td>
			<td>Meiliza Putri</td>
			<td>17420021</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		</tr>

		</table>
<div class="alert alert-primary"><h3>Tabel Bootstrap Hover</h3></div>
		<table class="table table-hover">
			<tr>
				<th>Nomor</th>
				<th>Nama</th>
				<th>NPM</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>Program Studi</th>
			</tr>
			<tr>
			<td>1</td>
			<td>Lega</td>
			<td>17420013</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>2</td>
			<td>Ella Sari Gustini</td>
			<td>17420014</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>3</td>
			<td>Meiliza Putri</td>
			<td>17420021</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		</tr>

		</table>
<div class="alert alert-primary"><h3>Tabel Bootstrap dark</h3></div>
		<table class="table table-dark">
			<tr>
				<th>Nomor</th>
				<th>Nama</th>
				<th>NPM</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>Program Studi</th>
			</tr>
			<tr>
			<td>1</td>
			<td>Lega</td>
			<td>17420013</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>2</td>
			<td>Ella Sari Gustini</td>
			<td>17420014</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>3</td>
			<td>Meiliza Putri</td>
			<td>17420021</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		</tr>

		</table>
<div class="alert alert-primary"><h3>Tabel Bootstrap</h3></div>
		<table class="table">
			
			<thead class="thead-dark">
				<th>Nomor</th>
				<th>Nama</th>
				<th>NPM</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>Program Studi</th>
			</tr>
			<tr>
			<td>1</td>
			<td>Lega</td>
			<td>17420013</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>2</td>
			<td>Ella Sari Gustini</td>
			<td>17420014</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		<tr>
			<td>3</td>
			<td>Meiliza Putri</td>
			<td>17420021</td>
			<td>Perempuan</td>
			<td>Pagar Alam</td>
			<td>Teknik Informatika</td>
		
		</tr>
		</table>
		</div>
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/booststrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/booststrap.min.js"></script>
   
   </body>
   </html>