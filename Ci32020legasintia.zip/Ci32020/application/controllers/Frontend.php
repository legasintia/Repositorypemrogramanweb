<?php

class Frontend extends CI_Controller{
		public function index(){
			$this->load->view('templete/header');
		
			$this->load->view('templete/navbar');
		
			$this->load->view('content');
			$this->load->view('templete/footer');
		}
	}
