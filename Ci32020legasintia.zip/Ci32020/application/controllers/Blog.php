<?php

class Blog extends CI_Controller {
	public function index(){
		$this->load->view('blog/website');
		}
		public function website(){
		$this->load->view('website');
				}
				public function tabel (){
				$this->load->view('boostrap/table');
				}
			}