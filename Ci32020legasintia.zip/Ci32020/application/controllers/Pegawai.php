<?php

class Pegawai extends CI_Controller{
	public function index(){
		$data['pegawai'] = $this->m_pegawai->view_pgw()->result();
		$this->load->view('templete/header');
		$this->load->view('templete/navbar');
		$this->load->view('pegawai',$data);
		$this->load->view('templete/footer');
	}

	public function add(){
		$nip = $this->input->post('nip');
		$nama = $this->input->post('nama');
		$jk = $this->input->post('jk');
		$jabatan = $this->input->post('jabatan');

		$data =array(
						'nip'  => $nip,
						'nama'  => $nama,
						'jk'  => $jk,
						'jabatan'  => $jabatan,
					);
		$this->m_pegawai->input_data($data,'tb_pegawai');
		redirect('pegawai/index');
	}
	public function edit ($id){
		$where = array('id' =>$id);
		$data['pegawai']=$this->m_pegawai->edit_data($where,'tb_pegawai')->result();

		$this->load->view('templete/header');
		$this->load->view('templete/navbar');
		$this->load->view('edit',$data);
		$this->load->view('templete/footer');
	}
	}
