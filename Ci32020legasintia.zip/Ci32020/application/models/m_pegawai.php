<?php

class M_pegawai extends  CI_Model{
	public function view_pgw(){
		return $this->db->get('tb_pegawai');
	}

	public function inpu_data($data,$table){
		$this->db->insert($table,$data);
	}
	public function edit_data($where, $table){
		return $this->db->get_where($table, $where);
	}
}